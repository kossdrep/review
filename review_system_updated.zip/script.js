function rate(stars) {
  if (stars >= 4) {
    window.location.href = "https://maps.app.goo.gl/WWB4ZqHCcaKKPsJa8";
  } else {
    window.location.href = "feedback.html";
  }
}
